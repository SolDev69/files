#!/usr/bin/env bash

arch=ppc64el

. .gitlab-ci/container/cross_build.sh
