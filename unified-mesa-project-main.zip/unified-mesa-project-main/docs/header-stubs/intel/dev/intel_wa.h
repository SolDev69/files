enum intel_workaround_id {
   INTEL_WA_NUM
};
