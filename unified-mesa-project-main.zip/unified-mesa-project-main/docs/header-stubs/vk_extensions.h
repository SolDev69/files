struct vk_instance_extension_table {};
struct vk_instance_entrypoint_table {};
