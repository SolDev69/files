typedef enum { nir_num_intrinsics = 0 } nir_intrinsic_op;
typedef enum { NIR_INTRINSIC_NUM_INDEX_FLAGS } nir_intrinsic_index_flag;
